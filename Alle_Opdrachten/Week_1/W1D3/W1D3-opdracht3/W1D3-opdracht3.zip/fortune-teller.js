const tellFortune=function(childrenNumber, partnerName, location, jobTitle){

console.log("You will be a "+ jobTitle+ " in "+location+", and married to "+partnerName+" with "+childrenNumber+" kids.");
}

tellFortune(4, "Bert", "America", "carpenter");
tellFortune(7, "Marga", "India", "imam");
tellFortune(0, "Ferdinand", "Hungary", "archaeologist");
