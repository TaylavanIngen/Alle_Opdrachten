const calculateDogAge=function(puppyAge){

  console.log("Your doggie is "+(puppyAge*7)+" years old in human years!");
}

calculateDogAge(4);
calculateDogAge(9);
calculateDogAge(15);
