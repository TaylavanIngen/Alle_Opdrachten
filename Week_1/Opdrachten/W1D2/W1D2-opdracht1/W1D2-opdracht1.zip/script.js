console.log("Hello, Winc Academy!");

let name="Tayla";

console.log(name);

var number1=12;
var number2=34;

console.log(number1+number2);

number2="34"

console.log(number1+number2);

var age=23;

console.log(typeof age);

var age="23";

console.log(typeof age);
